===========================================================

                                       _ _
     _ __ ___   __ _  __ _ _ __   ___ | (_) __ _  (R)
    | '_ ` _ \ / _` |/ _` | '_ \ / _ \| | |/ _` |
    | | | | | | (_| | (_| | | | | (_) | | | (_| |
    |_| |_| |_|\__,_|\__, |_| |_|\___/|_|_|\__,_|
                     |___/


        7. March 2016
        v 5.4.5
        Community Edition

        http://www.magnolia-cms.com/

===========================================================

Magnolia webapp pre-bundled with the DAM module and Magnolia Templating Essentials.

This package contains:

   Magnolia Core 5.4.5
   magnolia-empty-webapp 5.4.5
   magnolia-empty-webapp 5.4.5
   Magnolia Internationalization Framework 5.4.5
   Magnolia Imaging Support Module 3.2.5
   Magnolia JAAS 5.4.5
   Magnolia Commenting Module 2.3.1
   Magnolia Form Module 2.3.4
   magnolia-module-forum 3.5
   Google Sitemap Module 2.3.3
   magnolia-module-groovy 2.4.3
   Magnolia Imaging Module 3.2.5
   Magnolia Inplace-templating Module 2.4.2
   Magnolia Legacy UI 5.3.1
   magnolia-module-mail 5.3
   magnolia-module-public-user-registration 2.5.2
   magnolia-module-rssaggregator 2.4.1
   Magnolia Rendering 5.4.5
   Magnolia Templating 5.4.5
   Magnolia Templating for JSP 5.4.5


===========================================================
Installation
===========================================================

Installation instructions can be found at:
    http://documentation.magnolia-cms.com/install.html


===========================================================
Documentation, Licensing & Support
===========================================================

You can find documentation at:
    http://documentation.magnolia-cms.com/

More information about this release can be found at:
    http://documentation.magnolia-cms.com/releases/5.4.5.html

Feel free to join the community and contribute through
bug reports, documentation, discussions, and more to help
improve Magnolia!
    http://www.magnolia-cms.com/community.html

For details on commercial services and support regarding
Magnolia, please visit:
    http://www.magnolia-cms.com/support-and-services.html

THIS SOFTWARE IS PROVIDED "AS-IS" AND FREE OF CHARGE, WITH
ABSOLUTELY NO WARRANTY OR SUPPORT OF ANY KIND, EXPRESSED OR
IMPLIED, UNDER THE TERMS OF THE INCLUDED LICENSE AGREEMENT.

Thank you for using Magnolia.

Magnolia International Ltd.
info@magnolia-cms.com


===========================================================

Copyright 2016 Magnolia International Ltd.

Magnolia is a registered trademark of
Magnolia International Ltd.

http://www.magnolia-cms.com
All rights reserved.
